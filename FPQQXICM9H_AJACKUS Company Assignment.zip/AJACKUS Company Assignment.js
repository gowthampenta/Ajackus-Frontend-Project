// Sample mock data
let employees = [{
        id: 1,
        firstName: "John",
        lastName: "Doe",
        email: "john@example.com",
        department: "HR",
        role: "Manager"
    },
    {
        id: 2,
        firstName: "Jane",
        lastName: "Smith",
        email: "jane@example.com",
        department: "IT",
        role: "Developer"
    },
    {
        id: 3,
        firstName: "Max",
        lastName: "Payne",
        email: "max@example.com",
        department: "Finance",
        role: "Analyst"
    },
    {
        id: 4,
        firstName: "Sara",
        lastName: "Connor",
        email: "sara@example.com",
        department: "IT",
        role: "Developer"
    }
];

let currentPage = 1;
let itemsPerPage = 2;

function renderList() {
    const list = document.getElementById("employee-list");
    list.innerHTML = "";

    const filtered = getFilteredEmployees();
    const paginated = paginate(filtered, currentPage, itemsPerPage);

    paginated.forEach(emp => {
        const card = document.createElement("div");
        card.className = "employee-card";
        card.innerHTML = `
      <h3>${emp.firstName} ${emp.lastName}</h3>
      <p>Email: ${emp.email}</p>
      <p>Department: ${emp.department}</p>
      <p>Role: ${emp.role}</p>
      <button onclick="editEmployee(${emp.id})">Edit</button>
      <button onclick="deleteEmployee(${emp.id})">Delete</button>
    `;
        list.appendChild(card);
    });

    renderPagination(filtered.length);
}

function renderPagination(totalItems) {
    const container = document.getElementById("pagination-controls");
    container.innerHTML = "";

    const totalPages = Math.ceil(totalItems / itemsPerPage);
    for (let i = 1; i <= totalPages; i++) {
        const btn = document.createElement("button");
        btn.textContent = i;
        if (i === currentPage) btn.classList.add("active");
        btn.onclick = () => {
            currentPage = i;
            renderList();
        };
        container.appendChild(btn);
    }
}

function showForm(id = null) {
    document.getElementById("employee-form").classList.remove("hidden");
    document.getElementById("dashboard").style.display = "none";
    document.getElementById("form-title").innerText = id ? "Edit Employee" : "Add Employee";
    const form = document.getElementById("form");

    if (id) {
        const emp = employees.find(e => e.id === id);
        form.empId.value = emp.id;
        form.firstName.value = emp.firstName;
        form.lastName.value = emp.lastName;
        form.email.value = emp.email;
        form.department.value = emp.department;
        form.role.value = emp.role;
    } else {
        form.reset();
        form.empId.value = "";
    }
}

function cancelForm() {
    document.getElementById("employee-form").classList.add("hidden");
    document.getElementById("dashboard").style.display = "block";
}

function deleteEmployee(id) {
    if (confirm("Are you sure you want to delete this employee?")) {
        employees = employees.filter(e => e.id !== id);
        renderList();
    }
}

function editEmployee(id) {
    showForm(id);
}

function getFilteredEmployees() {
    const search = document.getElementById("search").value.toLowerCase();
    const filterName = document.getElementById("filterName").value.toLowerCase();
    const filterDept = document.getElementById("filterDept").value;
    const filterRole = document.getElementById("filterRole").value;

    return employees.filter(emp => {
        const fullName = `${emp.firstName} ${emp.lastName}`.toLowerCase();
        const matchesSearch = fullName.includes(search) || emp.email.toLowerCase().includes(search);
        const matchesName = !filterName || emp.firstName.toLowerCase().includes(filterName);
        const matchesDept = !filterDept || emp.department === filterDept;
        const matchesRole = !filterRole || emp.role === filterRole;
        return matchesSearch && matchesName && matchesDept && matchesRole;
    });
}

function applyFilters() {
    currentPage = 1;
    renderList();
}

function paginate(data, page, perPage) {
    const start = (page - 1) * perPage;
    return data.slice(start, start + perPage);
}

document.getElementById("search").addEventListener("input", () => {
    currentPage = 1;
    renderList();
});

document.getElementById("form").addEventListener("submit", function(e) {
    e.preventDefault();

    const id = this.empId.value;
    const firstName = this.firstName.value.trim();
    const lastName = this.lastName.value.trim();
    const email = this.email.value.trim();
    const department = this.department.value.trim();
    const role = this.role.value.trim();

    if (!firstName || !lastName || !email || !department || !role) {
        alert("Please fill in all fields.");
        return;
    }

    const emailPattern = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
    if (!emailPattern.test(email)) {
        alert("Invalid email format.");
        return;
    }

    if (id) {
        const emp = employees.find(e => e.id == id);
        Object.assign(emp, {
            firstName,
            lastName,
            email,
            department,
            role
        });
    } else {
        const newEmployee = {
            id: Date.now(),
            firstName,
            lastName,
            email,
            department,
            role
        };
        employees.push(newEmployee);
    }

    cancelForm();
    renderList();
});

// Initial page setup
window.onload = () => {
    renderList();
    document.getElementById("employee-form").classList.add("hidden");

    // Create dashboard container wrapper
    const dashboardDiv = document.createElement("div");
    dashboardDiv.id = "dashboard";
    const controls = document.querySelector(".controls");
    const filters = document.querySelector(".filters");
    const list = document.getElementById("employee-list");
    const pagination = document.getElementById("pagination-controls");

    controls.before(dashboardDiv);
    dashboardDiv.appendChild(controls);
    dashboardDiv.appendChild(filters);
    dashboardDiv.appendChild(list);
    dashboardDiv.appendChild(pagination);
};